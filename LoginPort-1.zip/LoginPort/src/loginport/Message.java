package loginport;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * This class handles all message creation, validation, and management.
 */
public class Message {

    // -------- MESSAGE FIELDS --------
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // -------- SHARED MESSAGE STORE --------
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static int messageCount = 0;

    // -------- CONSTRUCTOR --------
    public Message(String recipient, String messageText) {
        messageCount++;
        this.messageID     = generateMessageID();
        this.messageNumber = messageCount;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageHash   = createMessageHash();
    }

    // -------- GENERATE RANDOM 10-DIGIT MESSAGE ID --------
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long)(rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // -------- CHECK MESSAGE ID --------
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // -------- CHECK RECIPIENT CELL --------
    public String checkRecipientCell() {
        if (!recipient.startsWith("+")) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        return "Cell phone number successfully captured.";
    }

    // -------- CREATE MESSAGE HASH --------
    public String createMessageHash() {
        String firstTwo  = messageID.substring(0, 2);
        String[] words   = messageText.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "");
        String lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z]", "");
        return (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // -------- CHECK MESSAGE LENGTH --------
    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int over = messageText.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    // -------- SEND, STORE OR DISREGARD MESSAGE --------
    public String sentMessage() {
        Scanner input = new Scanner(System.in);
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message");
        System.out.print("Select an option: ");

        String choice = input.nextLine();

        switch (choice) {
            case "1":
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";
            case "2":
                return "Press 0 to delete the message.";
            case "3":
                storeMessage();
                return "Message successfully stored.";
            default:
                return "No option selected.";
        }
    }

    // -------- PRINT ALL SENT MESSAGES --------
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("\nMessage ID   : ").append(m.messageID).append("\n");
            sb.append("Message Hash : ").append(m.messageHash).append("\n");
            sb.append("Recipient    : ").append(m.recipient).append("\n");
            sb.append("Message      : ").append(m.messageText).append("\n");
            sb.append("----------------------------");
        }
        return sb.toString();
    }

    // -------- RETURN TOTAL MESSAGES SENT --------
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // -------- STORE MESSAGE IN JSON --------
    public void storeMessage() {
        // Builds a simple JSON entry for this message
        String json = "{\n" +
                "  \"messageID\": \""   + messageID   + "\",\n" +
                "  \"messageHash\": \"" + messageHash + "\",\n" +
                "  \"recipient\": \""   + recipient   + "\",\n" +
                "  \"message\": \""     + messageText + "\"\n"  +
                "}";

        // Writes JSON entry to file
        try {
            java.io.FileWriter fw = new java.io.FileWriter("messages.json", true);
            fw.write(json + ",\n");
            fw.close();
        } catch (java.io.IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // -------- GETTERS --------
    public String getMessageID()     { return messageID;     }
    public String getRecipient()     { return recipient;     }
    public String getMessageText()   { return messageText;   }
    public String getMessageHash()   { return messageHash;   }
    public int    getMessageNumber() { return messageNumber; }
}

