package loginport;

import java.util.Scanner;

/**
 * Main class handles registration, login, and the QuickChat messaging menu.
 */
public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        // -------- REGISTRATION --------
        boolean registered = false;
        while (!registered) {

            System.out.println("\n--- Register ---");
            System.out.print("Enter username: ");
            String username = input.nextLine();
            System.out.print("Enter password: ");
            String password = input.nextLine();
            System.out.print("Enter phone number (+27...): ");
            String phone = input.nextLine();

            // -------- VALIDATION FEEDBACK --------
            String userMessage  = login.checkUsername(username);
            String passMessage  = login.checkPassword(password);
            String phoneMessage = login.checkPhone(phone);

            System.out.println("\n--- Validation Results ---");
            System.out.println(userMessage);
            System.out.println(passMessage);
            System.out.println(phoneMessage);

            // -------- REGISTRATION CHECK --------
            String result = login.registerUser(username, password, phone);
            if (result.equals("Registration successful.")) {
                System.out.println("Registration successful.");
                registered = true;
            } else {
                System.out.println("Please fix the above issues and try again.");
            }
        }

        // -------- LOGIN --------
        boolean loggedIn = false;
        while (!loggedIn) {

            System.out.println("\n--- Login ---");
            System.out.print("Enter username: ");
            String username = input.nextLine();
            System.out.print("Enter password: ");
            String password = input.nextLine();
            System.out.print("Enter phone number: ");
            String phone = input.nextLine();

            if (login.login(username, password, phone)) {
                System.out.println("Login successful. Welcome!");
                loggedIn = true;
            } else {
                System.out.println("Login failed. Incorrect details.");
            }
        }

        // -------- WELCOME MESSAGE --------
        System.out.println("\nWelcome to QuickChat.");

        // -------- NUMBER OF MESSAGES --------
        int numMessages = 0;
        while (numMessages <= 0) {
            System.out.print("How many messages would you like to send? ");
            try {
                numMessages = Integer.parseInt(input.nextLine());
                if (numMessages <= 0) {
                    System.out.println("Please enter a number greater than 0.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        // -------- MAIN MENU LOOP --------
        boolean running = true;
        int messagesSentSoFar = 0;

        while (running) {

            System.out.println("\n=== QUICKCHAT MENU ===");
            System.out.println("1) Send Messages");
            System.out.println("2) Show Recently Sent Messages");
            System.out.println("3) Quit");
            System.out.print("Select an option: ");

            String menuChoice = input.nextLine();

            switch (menuChoice) {

                // -------- OPTION 1: SEND MESSAGES --------
                case "1":
                    if (messagesSentSoFar >= numMessages) {
                        System.out.println("You have reached your message limit of " + numMessages + ".");
                        break;
                    }

                    // -------- COLLECT MESSAGE DETAILS --------
                    System.out.print("Enter recipient cell number: ");
                    String recipient = input.nextLine();
                    System.out.print("Enter your message: ");
                    String messageText = input.nextLine();

                    // -------- VALIDATE MESSAGE LENGTH --------
                    if (messageText.length() > 250) {
                        int over = messageText.length() - 250;
                        System.out.println("Message exceeds 250 characters by " + over +
                                "; please reduce the size.");
                        break;
                    }

                    // -------- CREATE MESSAGE OBJECT --------
                    Message message = new Message(recipient, messageText);

                    // -------- VALIDATE RECIPIENT --------
                    String recipientCheck = message.checkRecipientCell();
                    System.out.println(recipientCheck);

                    if (!recipientCheck.equals("Cell phone number successfully captured.")) {
                        break;
                    }

                    // -------- SEND, STORE OR DISREGARD --------
                    String outcome = message.sentMessage();
                    System.out.println(outcome);

                    // -------- DISPLAY FULL MESSAGE DETAILS IF SENT --------
                    if (outcome.equals("Message successfully sent.")) {
                        messagesSentSoFar++;
                        System.out.println("\n--- Message Details ---");
                        System.out.println("Message ID   : " + message.getMessageID());
                        System.out.println("Message Hash : " + message.getMessageHash());
                        System.out.println("Recipient    : " + message.getRecipient());
                        System.out.println("Message      : " + message.getMessageText());
                    }

                    // -------- DISPLAY TOTAL WHEN LIMIT REACHED --------
                    if (messagesSentSoFar == numMessages) {
                        System.out.println("\nAll messages sent!");
                        System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    }
                    break;

                // -------- OPTION 2: SHOW RECENTLY SENT --------
                case "2":
                    System.out.println("Coming Soon.");
                    break;

                // -------- OPTION 3: QUIT --------
                case "3":
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    System.out.println("Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Please select a valid option.");
                    break;
            }
        }
    }
}