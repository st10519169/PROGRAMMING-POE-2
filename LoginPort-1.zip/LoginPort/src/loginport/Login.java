/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginport;

/**
 * This class validates user input and returns helpful feedback messages.
 */
public class Login {

    // -------- STORED USER DETAILS --------
    private String storedUsername;
    private String storedPassword;
    private String storedPhone;

    // -------- USERNAME VALIDATION --------
    public String checkUsername(String username) {
        if (username.length() > 5) {
            return "Username must not be more than 5 characters.";
        }
        if (!username.contains("_")) {
            return "Username must contain an underscore (_).";
        }
        return "Username is valid.";
    }

    // -------- PASSWORD VALIDATION --------
    public String checkPassword(String password) {
        if (password.length() < 8) {
            return "Password must be at least 8 characters long.";
        }
        if (!password.matches(".*[A-Z].*")) {
            return "Password must include at least one uppercase letter.";
        }
        if (!password.matches(".*\\d.*")) {
            return "Password must include at least one number.";
        }
        if (!password.matches(".*[^a-zA-Z0-9].*")) {
            return "Password must include at least one special character.";
        }
        return "Password is valid.";
    }

    // -------- PHONE VALIDATION --------
    public String checkPhone(String phone) {
        if (!phone.startsWith("+27")) {
            return "Phone number must start with +27.";
        }
        if (phone.length() != 12) {
            return "Phone number must be 12 characters long (including +27).";
        }
        return "Phone number is valid.";
    }

    // -------- REGISTER USER --------
    public String registerUser(String username, String password, String phone) {
        String userMsg  = checkUsername(username);
        String passMsg  = checkPassword(password);
        String phoneMsg = checkPhone(phone);
        if (userMsg.equals("Username is valid.") &&
            passMsg.equals("Password is valid.") &&
            phoneMsg.equals("Phone number is valid.")) {
            storedUsername = username;
            storedPassword = password;
            storedPhone    = phone;
            return "Registration successful.";
        }
        return userMsg + "\n" + passMsg + "\n" + phoneMsg;
    }

    // -------- LOGIN CHECK --------
    public boolean login(String username, String password, String phone) {
        return username.equals(storedUsername) &&
               password.equals(storedPassword) &&
               phone.equals(storedPhone);
    }
}