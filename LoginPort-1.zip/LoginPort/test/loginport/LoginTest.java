/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package loginport;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    Login login = new Login();

    // ---------------- USERNAME TESTS ----------------
    @Test
    public void testCheckUsername() {
        assertEquals("Username is valid.", login.checkUsername("ab_c"));
        assertEquals("Username must contain an underscore (_).", login.checkUsername("abc"));
        assertEquals("Username must not be more than 5 characters.", login.checkUsername("abcdef"));
    }

    // ---------------- PASSWORD TESTS ----------------
    @Test
    public void testCheckPassword() {
        assertEquals("Password is valid.", login.checkPassword("Password1!"));
        assertEquals("Password must be at least 8 characters long.", login.checkPassword("pass"));
    }

    // ---------------- PHONE TESTS ----------------
    @Test
    public void testCheckPhone() {
        assertEquals("Phone number is valid.", login.checkPhone("+27821234567"));
        assertEquals("Phone number must start with +27.", login.checkPhone("0821234567"));
    }

    // ---------------- LOGIN TEST ----------------
    @Test
    public void testLogin() {

        // MUST register first (important for stored login system)
        login.registerUser("ab_c", "Password1!", "+27821234567");

        // valid login
        assertTrue(login.login("ab_c", "Password1!", "+27821234567"));

        // invalid login
        assertFalse(login.login("wrong", "pass", "+27821234567"));
    }
}