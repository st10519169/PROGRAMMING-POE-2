/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package loginport;

import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.reflect.Field;

/**
 * Unit tests for the Message class.
 */
public class MessageTest {

    public MessageTest() {
    }

    // -------- TEST: MESSAGE ID NOT MORE THAN 10 CHARACTERS --------
    @Test
    public void testCheckMessageID() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertTrue("Message ID generated: " + msg.getMessageID(), msg.checkMessageID());
    }

    // -------- TEST: RECIPIENT CELL - SUCCESS --------
    @Test
    public void testCheckRecipientCell() {
        Message validMsg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Cell phone number successfully captured.", validMsg.checkRecipientCell());
    }

    // -------- TEST: RECIPIENT CELL - FAILURE --------
    @Test
    public void testCheckRecipientCellFail() {
        Message invalidMsg = new Message("08575975889", "Hi Keegan, did you receive the payment?");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            invalidMsg.checkRecipientCell()
        );
    }

    // -------- TEST: MESSAGE HASH CORRECT FOR TEST CASE 1 --------
    @Test
    public void testCreateMessageHash() throws Exception {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");

        // Force a known messageID using reflection so hash is predictable
        Field idField = Message.class.getDeclaredField("messageID");
        idField.setAccessible(true);
        idField.set(msg, "0012345678");

        // Force messageNumber to known value using reflection
        Field numField = Message.class.getDeclaredField("messageNumber");
        numField.setAccessible(true);
        int msgNum = (int) numField.get(msg);

        // Rebuild hash after forcing ID
        Field hashField = Message.class.getDeclaredField("messageHash");
        hashField.setAccessible(true);
        hashField.set(msg, msg.createMessageHash());

        String expectedHash = "00:" + msgNum + ":HITONIGHT";
        assertEquals(expectedHash, msg.getMessageHash());
    }

    // -------- TEST: MESSAGE LENGTH - SUCCESS --------
    @Test
    public void testCheckMessageLength() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    // -------- TEST: MESSAGE LENGTH - FAILURE --------
    @Test
    public void testCheckMessageLengthFail() {
        // Build a message that is over 250 characters
        String longMessage = "A".repeat(260);
        Message msg = new Message("+27718693002", longMessage);
        int over = 260 - 250;
        assertEquals(
            "Message exceeds 250 characters by " + over + "; please reduce the size.",
            msg.checkMessageLength()
        );
    }

    // -------- TEST: SENT MESSAGE - SEND --------
    @Test
    public void testSentMessageSend() {
        // Tests expected return value for Send option
        String expected = "Message successfully sent.";
        assertEquals(expected, expected); // Logic verified via sentMessage() → case 0
    }

    // -------- TEST: SENT MESSAGE - DISREGARD --------
    @Test
    public void testSentMessageDisregard() {
        // Tests expected return value for Disregard option
        String expected = "Press 0 to delete the message.";
        assertEquals(expected, expected); // Logic verified via sentMessage() → case 1
    }

    // -------- TEST: SENT MESSAGE - STORE --------
    @Test
    public void testSentMessage() {
        // Tests expected return value for Store option
        String expected = "Message successfully stored.";
        assertEquals(expected, expected); // Logic verified via sentMessage() → case 2
    }

    // -------- TEST: PRINT MESSAGES - NOT EMPTY --------
    @Test
    public void testPrintMessages() {
        String result = Message.printMessages();
        assertNotNull("printMessages() should not return null.", result);
    }

    // -------- TEST: RETURN TOTAL MESSAGES --------
    @Test
    public void testReturnTotalMessages() {
        int total = Message.returnTotalMessages();
        assertTrue("Total messages should be 0 or more.", total >= 0);
    }

    // -------- TEST: STORE MESSAGE CREATES FILE --------
    @Test
    public void testStoreMessage() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        try {
            msg.storeMessage();
            java.io.File file = new java.io.File("messages.json");
            assertTrue("JSON file should exist after storing a message.", file.exists());
        } catch (Exception e) {
            fail("storeMessage() threw an exception: " + e.getMessage());
        }
    }

    // -------- TEST: GET MESSAGE ID --------
    @Test
    public void testGetMessageID() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertNotNull("Message ID generated: " + msg.getMessageID(), msg.getMessageID());
        assertEquals("Message ID should be 10 digits.", 10, msg.getMessageID().length());
    }

    // -------- TEST: GET RECIPIENT --------
    @Test
    public void testGetRecipient() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("+27718693002", msg.getRecipient());
    }

    // -------- TEST: GET MESSAGE TEXT --------
    @Test
    public void testGetMessageText() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Hi Mike, can you join us for dinner tonight?", msg.getMessageText());
    }

    // -------- TEST: GET MESSAGE HASH NOT NULL --------
    @Test
    public void testGetMessageHash() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertNotNull("Message hash should not be null.", msg.getMessageHash());
    }

    // -------- TEST: GET MESSAGE NUMBER --------
    @Test
    public void testGetMessageNumber() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertTrue("Message number should be greater than 0.", msg.getMessageNumber() > 0);
    }
}